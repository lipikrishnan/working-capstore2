package repository;

import java.util.List;

import pojo.Actor;
import pojo.Film;

public interface FilmRepository {
	boolean save(Film film);
	boolean modifyFilm(Film film);
	boolean deleteFilm(Film film);
	List<Film> searchFilmByTitle(String title);
	List<Film> searchFilmByCategory(String category);
	List<Film> searchFilmByRating(short rating);
	List<Film> searchFilmByLanguage(String lang);
	List<Film> searchFilmByActor(Actor actor);
	List<Film> searchFilmByRealeaseYear(short year);
	

}
