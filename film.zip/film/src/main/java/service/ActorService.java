package service;

import java.util.ArrayList;
import java.util.List;

import interfaces.IActorService;
import pojo.Actor;
import pojo.Film;
import repository.ActorRepository;


public class ActorService implements IActorService 
{
	private ActorRepository fr;
	

	public ActorService(ActorRepository fr) 
	{
		super();
		this.fr = fr;
	}

	public ActorService() 
	{
		super();
	}

	public String addActor(Actor actor) 
	{

		Actor f=actor;
		
		if(f==null)
		{
			throw new NullPointerException();
		}
		else 
		{
			
			if(f.getFirstName()==null)throw new IllegalArgumentException();
			
			if(f.getLastName()==null)throw new IllegalArgumentException();
			if(f.getAlbum()==null)throw new IllegalArgumentException();
			if(f.getFilms()==null)throw new IllegalArgumentException();
			if(f.getGender()==null)throw new IllegalArgumentException();
		
			if(f.getDeleteDate()==null)throw new IllegalArgumentException();
			
			if(f.getCreateDate()==null)throw new IllegalArgumentException();
			
			try
			{
				fr.save(f);
				return "successfull";
			}
			catch(Exception e)
			{
				return "fail";
			}
		}

	}

	public List<Actor> searchByName(String firstName, String lastName)
	{

		List<Actor> actor=null;
		if(firstName==null||lastName==null)
			throw new NullPointerException();
		try
		{
			 actor=fr.searchByName(firstName,lastName);
		}
		catch(Exception e){return null;}
		
		if(actor.isEmpty())
		{
			return null;
		}
		return  actor;
	}

	public List<Actor> searchByGender(String gender) 
	{
		
		List<Actor> actor=null;
		if(gender==null)
		{
			throw new NullPointerException();
		}
		try
		{
			 actor=fr.searchByGender(gender);
			
		}
		catch(Exception e)
		{
			return null;
		}
		
		if(actor.isEmpty())
		{
			return null;
		}
		
		return  actor;
	}

	

	public String modifyActor(Actor actor) 
	{
		if(actor==null)
		{
			throw new NullPointerException();
		}
		try
		{
			
			if(fr.modifyActor(actor))
			{
				System.out.println("s");
				return "succesfull";
			}
		}
		catch(Exception e)
		{
			System.out.println("f1");
			return "failed";
		}
		return "failed";
	}

	public String deleteActor(Actor actor) 
	{

		if(actor==null)
		{
			throw new NullPointerException();
		}
		try
		{
			if(fr.deleteActor(actor))
			{
				return "succesfull";
			}
			
			return "falied";
		}
		catch(Exception e)
		{
			return "System Error";
		}
		
	}

}
