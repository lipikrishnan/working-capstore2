package demo.film.industry;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.*;



public class FilmTest {
	public static void main(String[] args) {
		
EntityManagerFactory emf = Persistence.createEntityManagerFactory("hello");
		
		EntityManager em = emf.createEntityManager();
		FilmService service=new FilmService(em);
		
		em.getTransaction().begin();
		Image image1=service.addImage(1,"image1", new Date(),new Date());
		Image image2=service.addImage(2,"image2",new Date(),new Date());
		List<Image> img=new ArrayList<Image>();
		img.add(image1);
		img.add(image2);
		
		Image image3=service.addImage(3,"image3", new Date(),new Date());
		Image image4=service.addImage(4,"image4",new Date(),new Date());
		List<Image> newimg=new ArrayList<Image>();
		newimg.add(image3);
		newimg.add(image4);
	
	
		Album album1=service.addAlbum(3,"album1",newimg,new Date(),new Date());
		
		Album album2=service.addAlbum(4,"album2",newimg,new Date(),new Date());
		
		
		
		Actor actor1=service.createActor(1,"amitabh","bacchan","male",album1,new Date(),new Date());
		Actor actor2=service.createActor(2,"abc","xyz","male",album2,new Date(),new Date());
		List<Actor> actorlist=new ArrayList<Actor>();
		actorlist.add(actor1);
		actorlist.add(actor2);
		
		
		List<Category> cat1=new ArrayList<Category>();
		Category category1=service.addCategory(1,"category1",new Date(),new Date());
		Category category2=service.addCategory(2,"category2",new Date(),new Date());
		cat1.add(category1);
		cat1.add(category2);
		
		
		Film film1=service.addFilm(1,"sholey","abcd",new Date(),(byte)5,new Date(),new Date(),(short)34,actorlist,cat1,album1);
		Film film2=service.addFilm(2,"abcd2","Dance",new Date(),(byte)4,new Date(),new Date(),(short) 34,actorlist,cat1,album2);
		List<Film> filmlist=new ArrayList<Film>();
		filmlist.add(film1);
		filmlist.add(film2);

		System.out.println("persisted"+film1+"\n"+film2);
		em.getTransaction().commit();
		
		em.close();
		emf.close();
	
}
}