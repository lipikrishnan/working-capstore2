package demo.film.industry;

import java.util.Date;
import java.util.List;

import javax.persistence.*;

public class FilmService {

	protected EntityManager em;
	
	public FilmService(EntityManager em){
		this.em=em;
	}
	Film film=new Film();

public Film addFilm(int id,String title,String description,Date releaseYear,byte rating,Date deleteDate,Date createDate,short length,List<Actor> actor,List<Category> category,Album album){
	
		film.setId(id);
		film.setTitle(title);
		film.setDescription(description);
		film.setReleaseYear(releaseYear);
		film.setRating(rating);
		film.setDeleteDate(deleteDate);
		film.setCreateDate(createDate);
		film.setLength(length);
		
		film.setActor(actor);
		film.setCategory(category);
				film.setAlbum(album);
		em.persist(film);
	return film;
	}
public Actor createActor(int id,String firstName,String lastName,String gender,Album album,Date createDate,Date deleteDate){
	Actor actor=new Actor();
	actor.setId(id);
			actor.setFirstName(firstName);
			actor.setLastName(lastName);
			actor.setGender(gender);
			actor.setAlbum(album);
			actor.setCreateDate(createDate);
			actor.setDeleteDate(deleteDate);
			return actor;
			
}
	
		
	
	public Category addCategory(int id,String name,Date createDate,Date deleteDate){
		Category category=new Category();
		category.setId(id);
		category.setName(name);
		category.setCreateDate(createDate);
		category.setDeleteDate(deleteDate);
		
		return category;
		}
		
	public Album addAlbum(int id,String albumName,List<Image>image,Date createDate,Date deleteDate){
		Album album=new Album();
		album.setId(id);
		album.setAlbumName(albumName);
		album.setImage(image);
		album.setCreateDate(createDate);
		album.setDeleteDate(deleteDate);
		return album;
		
	}
	public Image addImage(int id,String imageURL,Date createDate,Date deleteDate)	{
		Image image=new Image();
		image.setId(id);
		image.setImageURL(imageURL);
		image.setCreateDate(createDate);
		image.setDeleteDate(deleteDate);
		return image;
		}
	
	}



