package demo.film.industry;

import java.util.List;

public interface IFilmService {
Film addFilm(Film film);
List<Film> searchFilmByTitle(String title);
Film modifyFilm(Film film);
Film deleteFilm(Film film);
List<Film> searchFilmByCategory(Film film);
List<Film> searchFilmByRating(Film film);
List<Film> searchFilmByLanguage(Film film);
List<Film> searchFilmByActor(Film film);
}
