package demo.film.industry;
import java.util.Date;
import java.util.List;

import javax.persistence.*;

@Entity
public class Film {

	@Id
	public int id;
	private String title;
	private String description;
	private Date releaseYear;
	
	@OneToOne
	Album album;
	private String language;
	
	@ManyToMany
	List<Actor>actor;
	
	@ManyToMany
	List<Category>category;
	byte rating;
	Date deleteDate;
	short length;
	Date createDate;
	public Film(){
		
	}
	public Film(int id,String title,String description,Date releaseYear,byte rating,Date deleteDate,Date createDate,short length,Actor actor,Category category,Album album){
		this.id=id;
		this.title=title;
		this.description=description;
		this.releaseYear=releaseYear;
		this.album=album;
		this.language=language;
		this.actor=(List<Actor>) actor;
		this.category=(List<Category>) category;
		this.rating=rating;
		this.deleteDate=deleteDate;
		this.createDate=createDate;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Date getReleaseYear() {
		return releaseYear;
	}
	public void setReleaseYear(Date releaseYear) {
		this.releaseYear = releaseYear;
	}
	public Album getAlbum() {
		return album;
	}
	public void setAlbum(Album album) {
		this.album = album;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public List<Actor> getActor() {
		return actor;
	}
	public void setActor(List<Actor> actor) {
		this.actor = actor;
	}
	public List<Category> getCategory() {
		return category;
	}
	public void setCategory(List<Category> category) {
		this.category = category;
	}
	public byte getRating() {
		return rating;
	}
	public void setRating(byte rating) {
		this.rating = rating;
	}
	public short getLength() {
		return length;
	}
	public void setLength(short length) {
		this.length = length;
	}
	public Date getDeleteDate() {
		return deleteDate;
	}
	public void setDeleteDate(Date deleteDate) {
		this.deleteDate = deleteDate;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	@Override
	public String toString() {
		return "Film [id=" + id + ", title=" + title + ", description=" + description + ", releaseYear=" + releaseYear
				+ ", album=" + album + ", language=" + language + ", actor=" + actor + ", category=" + category
				+ ", rating=" + rating + ", deleteDate=" + deleteDate + ", length=" + length + ", createDate="
				+ createDate + "]";
	}
	
}
