package service;

import java.util.List;
import demo.film.industry.*;
import java.util.Date;
import dao.*;
import javax.persistence.EntityManager;

public class IFilmServiceImpl implements IFilmService{

	protected FilmDAOImpl filmDao;

	public IFilmServiceImpl(FilmDAOImpl filmDao) {
		super();
		this.filmDao = filmDao;
	}

	public Film addFilm(Film film){
		Film f=film;
		if(film==null){
			throw new NullPointerException();
		}
		if(filmDao.addFilm(f)){
			return f;
		}
		
			return null;
		
		
	}
	
	public List<Film> searchFilmByTitle(String title){
		if(title==null){
			throw new IllegalArgumentException();
		}	
		return filmDao.searchFilmByTitle(title);
	}

	public List<Film> searchFilmByRating(byte rating) {	
		if(rating==0){
			throw new NullPointerException();
		}
		return filmDao.searchFilmByRating(rating);
	}

	public List<Film> searchFilmByActor(Actor actor) {
		if(actor==null){
			throw new NullPointerException();
		}		
		return filmDao.searchFilmByActor(actor);
	}

	public List<Film> searchFilmByCategory(Category category) {
		if(category==null){
			throw new NullPointerException();
		}		
		return filmDao.searchFilmByCategory(category);
	}

	public List<Film> searchFilmByLanguage(String language) {
		if(language==null){
			throw new NullPointerException();
		}		
		return filmDao.searchFilmByLanguage(language);
	}

	public List<Film> searchFilmByReleaseYear(Date date) {
		if(date==null){
			throw new NullPointerException();
		}	
		return filmDao.searchFilmByReleaseYear(date);
	}
	public String modifyFilm(Film film) {
		if(film==null){
			throw new NullPointerException();
		}
		
			if(filmDao.updateFilm(film).equals("Film updated successfully")){
			return "Film updated successfully";
			}
			else
			{
				return "Film updation failed";
			}
		
	}

	public String deleteFilm(Film film) {
		if(film==null){
			throw new NullPointerException();
		}
		
			if(filmDao.removeFilm(film).equals("Film deleted")){
				
			return "Film deleted";
			}
			else{
		return "Film deletion failed";
		}
	}

	public List<Film> getAllFilm(List<Film> film) {
		if(film==null){
			throw new NullPointerException();
		}
		return filmDao.getAllFilm(film);
	}

//	public Image createImage(int id, String imageURL, Date createDate, Date deleteDate){
//		Image image=new Image();
//		image.setCreateDate(createDate);
//		image.setDeleteDate(deleteDate);
//		image.setId(id);
//		image.setImageURL(imageURL);
//		em.persist(image);
//		
//		return image;
//	}
//	
//	public Album createAlbum(int id, String albumName, List<Image> image, Date createDate, Date deleteDate){
//		Album album=new Album();
//		album.setAlbumName(albumName);
//		album.setCreateDate(createDate);
//		album.setDeleteDate(deleteDate);
//		album.setId(id);
//		album.setImage(image);
//		em.persist(album);
//		return album;
//	}
//	
	public Actor createActor(int id, String firstName, String lastName, String gender, Album album,	Date createDate, Date deleteDate){
		Actor actor=new Actor();
//		actor.setId(id);
//		actor.setFirstName(firstName);
//		actor.setLastName(lastName);
//		actor.setGender(gender);
//		actor.setAlbum(album);
//		actor.setCreateDate(createDate);
//		actor.setDeleteDate(deleteDate);
//		em.persist(actor);
		return actor;
	}
//	
	public Category createCategory(int id, String name, Date createDate, Date deleteDate){
		Category category = new Category();
//		category.setCreateDate(createDate);
//		category.setDeleteDate(deleteDate);
//		category.setId(id);
//		category.setName(name);
//		em.persist(category);
		return category;
	}


}
