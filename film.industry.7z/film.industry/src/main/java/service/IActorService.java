package service;
import java.util.List;
import demo.film.industry.*;
public interface IActorService {
String  addActor(Actor actor);
List<Actor> findActorByName(String name);
	List<Actor> searchActorByName(String name);
	
	List<Actor> searchActorByGender(String gender);
	
	String removeActor(Actor actor);
	
	Actor modifyActor(Actor actor);
}
