package service;
import java.util.Date;
import java.util.List;
import demo.film.industry.*;
import javax.persistence.EntityManager;
public class AlbumService {
protected EntityManager em;
	
	public AlbumService(EntityManager em){
		this.em=em;
	}
}
