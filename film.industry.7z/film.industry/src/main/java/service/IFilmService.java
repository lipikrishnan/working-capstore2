package service;

import java.util.List;
import dao.*;
import demo.film.industry.*;
public interface IFilmService {
Film addFilm(Film film);
List<Film> searchFilmByTitle(String title);
String modifyFilm(Film film);
String deleteFilm(Film film);
List<Film> searchFilmByCategory(Category category);
List<Film> searchFilmByRating(byte rating);
List<Film> searchFilmByLanguage(String language);
List<Film> searchFilmByActor(Actor actor);
List<Film> getAllFilm(List<Film> film);
}
