package service;
import java.util.Date;
import java.util.List;
import demo.film.industry.*;
import dao.*;
import javax.persistence.EntityManager;
public class ActorServiceImpl implements IActorService {
	protected EntityManager em;
	protected ActorDAOImpl actorDao;
		
		public ActorServiceImpl(EntityManager em){
			this.em=em;
		}
		
		public ActorServiceImpl(ActorDAOImpl actorDao) {
			super();
			this.actorDao = actorDao;
		}

		public String addActor(Actor actor){
			if(actor==null){
				throw new NullPointerException();
			}
			
			if( actorDao.addActor(actor)){
				return "Actor added";
			}
			return "Actor not added";
		}

		public List<Actor> findActorByName(String name) {
			return actorDao.findActorByName(name);
		}

		public String removeActor(Actor actor) {
			if(actor==null){
				throw new NullPointerException();
			}
			return actorDao.deleteActor(actor);
		}

		public Actor modifyActor(Actor actor) {
			return actorDao.updateActor(actor);
		}

		public List<Actor> searchActorByGender(String gender) {
			return actorDao.findActorByGender(gender);
		}
		public List<Actor> findActorByGender(String gender) {
			return actorDao.findActorByGender(gender);
		}

		public List<Actor> searchActorByName(String name) {
			// TODO Auto-generated method stub
			return null;
		}

		public String deleteFilm(Film film) {
			return null;
			
		}	
		
}
