package service;

import java.util.Date;

import javax.persistence.EntityManager;
import demo.film.industry.*;
public class ImageService {
protected EntityManager em;
	
	public ImageService(EntityManager em){
		this.em=em;
	}
}
