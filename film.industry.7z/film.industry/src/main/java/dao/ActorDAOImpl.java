package dao;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import demo.film.industry.*;
public class ActorDAOImpl implements IActorDAO{

	EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("hello");

	EntityManager entityManager=entityManagerFactory.createEntityManager();
	
	public boolean addActor(Actor actor) {
		return false;
	}

	public List<Actor> findActorByName(String name) {
		return null;
	}

	public String deleteActor(Actor actor) {
		return null;
	}

	public Actor updateActor(Actor actor) {
		return null;
	}

	public List<Actor> findActorByGender(String gender) {
		return null;
	}

	
}
