package dao;

import java.util.List;

import demo.film.industry.*;


public interface IFilmDAO {
	public boolean addFilm(Film film);
	
	public String updateFilm(Film film);
	
	public String removeFilm(Film film);
	
	public List<Film> searchFilmByTitle(String title);
	
	public List<Film> searchFilmByRating(byte rating);
	
	public List<Film> searchFilmByActor(Actor actor);
	
	public List<Film> searchFilmByCategory(Category category);
	
	public List<Film> searchFilmByLanguage(String language);
	
	public List<Film> getAllFilm(List<Film> film);
}
