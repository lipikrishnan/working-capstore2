package dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;

import demo.film.industry.*;


public class FilmDAOImpl implements IFilmDAO {
	protected EntityManager em;
	protected FilmDAOImpl filmDao;
	public FilmDAOImpl(EntityManager em){
		this.em=em;
	}
	public boolean addFilm(Film film) {
//		film.setActor(film.getActor());
//		film.setAlbum(film.getAlbum());
//		film.setCategory(film.getCategory());
//		film.setCreateDate(film.getCreateDate());
//		film.setDeleteDate(film.getDeleteDate());
//		film.setDescription(film.getDescription());
//		film.setId(film.getId());
//		film.setLanguage(film.getLanguage());
//		film.setLength(film.getLength());
//		film.setRating(film.getRating());
//		film.setReleaseYear(film.getReleaseYear());
//		film.setTitle(film.getTitle());
//		em.merge(film);
//		
		return false;
	}

	public String updateFilm(Film film) {
		
		return null;
	}

	public String removeFilm(Film film) {
		
		return null;
	}

	public List<Film> searchFilmByTitle(String title) {
		List<Film> filmList=new ArrayList<Film>();
		
		return filmList;
	}

	public List<Film> searchFilmByRating(byte rating) {
		
		List<Film> filmList=new ArrayList<Film>();
		return filmList;
	}

	public List<Film> searchFilmByActor(Actor actor) {
		
		List<Film> filmList=new ArrayList<Film>();
		return filmList;
	}

	public List<Film> searchFilmByCategory(Category category) {
		
		List<Film> filmList=new ArrayList<Film>();
		return filmList;
	}

	public List<Film> searchFilmByLanguage(String language) {
		
		List<Film> filmList=new ArrayList<Film>();
		return filmList;
	}

	public List<Film> getAllFilm(List<Film> film) {
		
		List<Film> filmList=new ArrayList<Film>();
		return filmList;
	}

	public List<Film> searchFilmByReleaseYear(Date date) {
		List<Film> filmList=new ArrayList<Film>();
		return filmList;
	}
	
	

}
