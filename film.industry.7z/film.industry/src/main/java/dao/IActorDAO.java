package dao;
import java.util.List;
import demo.film.industry.*;
public interface IActorDAO {
	boolean addActor(Actor actor);
	
	List<Actor> findActorByName(String name);
	
	List<Actor> findActorByGender(String gender);
	
	String deleteActor(Actor actor);
	
	Actor updateActor(Actor actor);
}
