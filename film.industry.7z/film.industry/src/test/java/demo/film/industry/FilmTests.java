package demo.film.industry;
import static org.junit.Assert.assertEquals;
import demo.film.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import demo.film.industry.*;
import dao.*;
import service.*;
public class FilmTests {
	private IFilmServiceImpl filmService;
	private ActorServiceImpl actorService;
	@Mock
	private FilmDAOImpl filmDao;
	@Mock
	private ActorDAOImpl actorDao;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		filmService = new IFilmServiceImpl(filmDao);
		actorService = new ActorServiceImpl(actorDao);

	}
	// Add Film
	// 1. If any parameter is invalid, value should not be added.
	// 2. If all the input parameters are valid, then the film object should be added.
	// 3. If all the parameters are valid but the film object is not added, then system should throw error.
	// 4. If input is null, it should throw null pointer exception.

	@Test
	public void invalidParameterForFilm() {
		Mockito.when(filmDao.addFilm(new Film())).thenReturn(false);
		assertEquals(null, filmService.addFilm(new Film()));
	}

	@Test
	public void validParameterForFilm() {
		Film film = new Film(1,"sholey","abcd",new Date(),(byte)5,new Date(),new Date(),(short)34,null,null,null);
		Mockito.when(filmDao.addFilm(film)).thenReturn(true);
		assertEquals(film, filmService.addFilm(film));
	}

	@Test
	public void systemErrorForFilm() {
		Film film = new Film(1,"sholey","abcd",new Date(),(byte)5,new Date(),new Date(),(short)34,null,null,null);
		Mockito.when(filmDao.addFilm(film)).thenReturn(false);
		assertEquals(null, filmService.addFilm(film));
	}

	@Test(expected=Exception.class)
	public void nullInputShouldThrowException() {
		Film film = new Film(1,"sholey","abcd",new Date(),(byte)5,new Date(),new Date(),(short)34,null,null,null);
		Mockito.when(filmDao.addFilm(null)).thenThrow(Exception.class);
		filmService.addFilm(null);
	}

	// Search By Title
	// 1. If input is null, it should not search.
	// 2. If input value is not present, it should throw error.
	// 3. If input value is present, then it should return film object.
	// 4. If the value is present and the system cannot return the object, then it should show error.

	@Test(expected=Exception.class)
	public void nullInputShouldNotSearchByTitle() {
		Film film = new Film(1,"sholey","abcd",new Date(),(byte)5,new Date(),new Date(),(short)34,null,null,null);
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(film);
		Mockito.when(filmDao.searchFilmByTitle(null)).thenThrow(Exception.class);
		filmService.searchFilmByTitle(null);
	}

	@Test
	public void invalidInputShouldNotSearchByTitle() {
		Film film = new Film(1,"sholey","abcd",new Date(),(byte)5,new Date(),new Date(),(short)34,null,null,null);
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(film);
		Mockito.when(filmDao.searchFilmByTitle("KK")).thenReturn(filmList);
		assertEquals(filmList, filmService.searchFilmByTitle("KK"));
	}

	@Test
	public void validInputShouldSearchByTitle() {
		Film film = new Film(1,"sholey","abcd",new Date(),(byte)5,new Date(),new Date(),(short)34,null,null,null);
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(film);
		Mockito.when(filmDao.searchFilmByTitle("DDLJ")).thenReturn(filmList);
		assertEquals(filmList, filmService.searchFilmByTitle("DDLJ"));
	}

	@Test
	public void validInputShouldNotSearchByTitle() {
		Film film = new Film(1,"sholey","abcd",new Date(),(byte)5,new Date(),new Date(),(short)34,null,null,null);
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(film);
		Mockito.when(filmDao.searchFilmByTitle("DDLJ")).thenReturn(null);
		assertEquals(null, filmService.searchFilmByTitle("DDLJ"));
	}

	// Search By Language
	// 1. If input is null, it should not search.
	// 2. If input value is not present, it should throw error.
	// 3. If input value is present, then it should return film object.
	// 4. If the value is present and the system cannot return the object, thenn it should show error.

	@Test(expected=NullPointerException.class)
	public void nullInputShouldNotSearchByLanguage() {
		Film film = new Film(1,"sholey","abcd",new Date(),(byte)5,new Date(),new Date(),(short)34,null,null,null);
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(film);
		Mockito.when(filmDao.searchFilmByLanguage(null)).thenThrow(NullPointerException.class);
		filmService.searchFilmByLanguage(null);
	}

	@Test
	public void invalidInputShouldNotSearchByLanguage() {
		Film film = new Film(1,"sholey","abcd",new Date(),(byte)5,new Date(),new Date(),(short)34,null,null,null);
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(film);
		Mockito.when(filmDao.searchFilmByLanguage("Marathi")).thenReturn(filmList);
		assertEquals(filmList, filmService.searchFilmByLanguage("Marathi"));
	}

	@Test
	public void validInputShouldSearchByLanguage() {
		Film film = new Film(1,"sholey","abcd",new Date(),(byte)5,new Date(),new Date(),(short)34,null,null,null);
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(film);
		Mockito.when(filmDao.searchFilmByLanguage("Hindi")).thenReturn(filmList);
		assertEquals(filmList, filmService.searchFilmByLanguage("Hindi"));
	}

	@Test
	public void validInputShouldNotSearchByLanguage() {
		Film film = new Film(1,"sholey","abcd",new Date(),(byte)5,new Date(),new Date(),(short)34,null,null,null);
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(film);
		Mockito.when(filmDao.searchFilmByLanguage("Hindi")).thenReturn(null);
		assertEquals(null,filmService.searchFilmByLanguage("Hindi"));
	}

	// Search By Rating
	// 1. If input is null, it should not search.
	// 2. If input value is not present, it should throw error.
	// 3. If input value is present, then it should return film object.
	// 4. If the value is present and the system cannot return the object, then it should show error.

	@Test(expected=NullPointerException.class)
	public void nullInputShouldNotSearchByRating() {
		Film film = new Film(1,"sholey","abcd",new Date(),(byte)5,new Date(),new Date(),(short)34,null,null,null);
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(film);
		try {
			Mockito.when(filmDao.searchFilmByRating( (byte)(0))).thenThrow(NullPointerException.class);
			filmService.searchFilmByRating( (byte)(0));
		} catch (IllegalArgumentException iae) {
		}
	}

	@Test
	public void invalidInputShouldNotSearchByRating() {
		Film film = new Film(1,"sholey","abcd",new Date(),(byte)5,new Date(),new Date(),(short)34,null,null,null);
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(film);
		Mockito.when(filmDao.searchFilmByRating((byte) 10)).thenReturn(filmList);
		assertEquals(filmList, filmService.searchFilmByRating((byte) 10));
	}

	@Test
	public void validInputShouldSearchByRating() {
		Film film = new Film(1,"sholey","abcd",new Date(),(byte)5,new Date(),new Date(),(short)34,null,null,null);
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(film);
		Mockito.when(filmDao.searchFilmByRating((byte) 4)).thenReturn(filmList);
		assertEquals(filmList, filmService.searchFilmByRating((byte) 4));
	}

	@Test
	public void validInputShouldNotSearchByRating() {
		Film film = new Film(1,"sholey","abcd",new Date(),(byte)5,new Date(),new Date(),(short)34,null,null,null);
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(film);
		Mockito.when(filmDao.searchFilmByRating((byte) 4)).thenReturn(null);
		assertEquals(null, filmService.searchFilmByRating((byte) 4));
	}

	// Search By Release Year
	// 1. If input is null, it should not search.
	// 2. If input value is not present, it should throw error.
	// 3. If input value is present, then it should return film object.
	// 4. If the value is present and the system cannot return the object, then it should show error.

	@Test(expected=NullPointerException.class)
	public void nullInputShouldNotSearchByReleaseYear() {
		Film film = new Film(1,"sholey","abcd",new Date(),(byte)5,new Date(),new Date(),(short)34,null,null,null);
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(film);
		Mockito.when(filmDao.searchFilmByReleaseYear(null)).thenThrow(NullPointerException.class);
		filmService.searchFilmByReleaseYear(null);
	}

	@Test
	public void invalidInputShouldNotSearchByReleaseYear() {
		Film film = new Film(1,"sholey","abcd",new Date(),(byte)5,new Date(),new Date(),(short)34,null,null,null);
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(film);
		SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM-dd");

		String input = "1818-11-11";
		try {
			Mockito.when(filmDao.searchFilmByReleaseYear(ft.parse(input))).thenReturn(filmList);

			assertEquals(filmList, filmService.searchFilmByReleaseYear(ft.parse(input)));
		} catch (ParseException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void validInputShouldSearchByReleaseYear() {
		Film film = new Film(1,"sholey","abcd",new Date(),(byte)5,new Date(),new Date(),(short)34,null,null,null);
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(film);
		Mockito.when(filmDao.searchFilmByReleaseYear(new Date())).thenReturn(filmList);
		assertEquals(filmList, filmService.searchFilmByReleaseYear(new Date()));
	}

	@Test
	public void validInputShouldNotSearchByReleaseYear() {
		Date date = new Date();
		Film film = new Film(1,"sholey","abcd",new Date(),(byte)5,new Date(),new Date(),(short)34,null,null,null);
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(film);
		Mockito.when(filmDao.searchFilmByReleaseYear(date)).thenReturn(null);
		assertEquals(null, filmService.searchFilmByReleaseYear(date));
		
	}

	// Search By Actor
	// 1. If input is null, it should not search.
	// 2. If input value is not present, it should throw error.
	// 3. If input value is present, then it should return film object.
	// 4. If the value is present and the system cannot return the object, then it should show error.

	@Test(expected=NullPointerException.class)
	public void nullInputShouldNotSearchByActor() {
		Actor actor1 = filmService.createActor(1, "Akshay", "Kumar", "Male", null, null, null);
		List<Actor> actorList = new ArrayList<Actor>();
		actorList.add(actor1);
		Film film = new Film(1,"sholey","abcd",new Date(),(byte)5,new Date(),new Date(),(short)34,null,null,null);
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(film);
		Mockito.when(filmDao.searchFilmByActor(null)).thenThrow(NullPointerException.class);
		filmService.searchFilmByActor(null);
	}

	
	
	@Test
	public void invalidInputShouldNotSearchByActor() {
		Actor actor1 = filmService.createActor(1, "Akshay", "Kumar", "Male", null, null, null);
		Actor actor2 = filmService.createActor(2, "Madhvan", "R", "Male", null, null, null);
		List<Actor> actorList = new ArrayList<Actor>();
		actorList.add(actor1);
		Film film = new Film(1,"sholey","abcd",new Date(),(byte)5,new Date(),new Date(),(short)34,null,null,null);
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(film);

		Mockito.when(filmDao.searchFilmByActor(actor2)).thenReturn(filmList);

		assertEquals(filmList,filmService.searchFilmByActor(actor2));
	}

	
	@Test
	public void validInputShouldSearchByActor() {
		Actor actor1 = filmService.createActor(1, "Akshay", "Kumar", "Male", null, null, null);
		List<Actor> actorList = new ArrayList<Actor>();
		actorList.add(actor1);
		Film film = new Film(1,"sholey","abcd",new Date(),(byte)5,new Date(),new Date(),(short)34,null,null,null);
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(film);
		Mockito.when(filmDao.searchFilmByActor(actor1)).thenReturn(filmList);
		assertEquals(filmList, filmService.searchFilmByActor(actor1));
	}

	
	@Test
	public void validInputShouldNotSearchByActor() {
		Date date = new Date();
		Actor actor1 = filmService.createActor(1, "Akshay", "Kumar", "Male", null, null, null);
		List<Actor> actorList = new ArrayList<Actor>();
		actorList.add(actor1);
		Film film = new Film(1,"sholey","abcd",new Date(),(byte)5,new Date(),new Date(),(short)34,null,null,null);
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(film);
		Mockito.when(filmDao.searchFilmByActor(actor1)).thenReturn(null);
		assertEquals(null, filmService.searchFilmByActor(actor1));
	}

	
	// Search By Category
	// 1. If input is null, it should not search.
	// 2. If input value is not present, it should throw error.
	// 3. If input value is present, then it should return film object.
	// 4. If the value is present and the system cannot return the object, then it should show error.

	@Test(expected=NullPointerException.class)
	public void nullInputShouldNotSearchByCategory() {
		Category category = filmService.createCategory(1, "Action", null, null);
		List<Category> categoryList = new ArrayList<Category>();
		categoryList.add(category);
		Film film = new Film(1,"sholey","abcd",new Date(),(byte)5,new Date(),new Date(),(short)34,null,null,null);
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(film);
		Mockito.when(filmDao.searchFilmByCategory(null)).thenThrow(NullPointerException.class);
		filmService.searchFilmByCategory(null);
	}

	
	@Test
	public void invalidInputShouldNotSearchByCategory() {
		Category category = filmService.createCategory(1, "Action", null, null);
		List<Category> categoryList = new ArrayList<Category>();
		categoryList.add(category);
		Film film = new Film(1,"sholey","abcd",new Date(),(byte)5,new Date(),new Date(),(short)34,null,null,null);
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(film);

		Mockito.when(filmDao.searchFilmByCategory(category)).thenReturn(filmList);

		assertEquals(filmList,filmService.searchFilmByCategory(category));
	}

	@Test
	public void validInputShouldSearchByCategory() {
		Category category = filmService.createCategory(1, "Action", null, null);
		List<Category> categoryList = new ArrayList<Category>();
		categoryList.add(category);
		Film film = new Film(1,"sholey","abcd",new Date(),(byte)5,new Date(),new Date(),(short)34,null,null,null);
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(film);
		Mockito.when(filmDao.searchFilmByCategory(category)).thenReturn(filmList);
		assertEquals(filmList, filmService.searchFilmByCategory(category));
	}

	@Test
	public void validInputShouldNotSearchByCategory() {
		Date date = new Date();
		Category category = filmService.createCategory(1, "Action", null, null);
		List<Category> categoryList = new ArrayList<Category>();
		categoryList.add(category);
		Film film = new Film(1,"sholey","abcd",new Date(),(byte)5,new Date(),new Date(),(short)34,null,null,null);
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(film);
		Mockito.when(filmDao.searchFilmByCategory(category)).thenReturn(null);
		assertEquals(null, filmService.searchFilmByCategory(category));
	}

	// Modify Film
	// 1. If input is null, it should not search.
	// 2. If input value is not present, it should throw error.
	// 3. If input value is present, then it should return film object.
	// 4. If the value is present and the system cannot return the object, then it should show error.

	@Test(expected=Exception.class)
	public void nullInputShouldNotModifyFilm() {
		Category category = filmService.createCategory(1, "Action", null, null);
		List<Category> categoryList = new ArrayList<Category>();
		categoryList.add(category);
		Film film = new Film(1,"sholey","abcd",new Date(),(byte)5,new Date(),new Date(),(short)34,null,null,null);
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(film);
		Mockito.when(filmDao.updateFilm(null)).thenThrow(Exception.class);
		filmService.modifyFilm(null);
	}

	@Test
	public void invalidInputShouldNotModifyFilm() {
		Category category = filmService.createCategory(1, "Action", null, null);
		List<Category> categoryList = new ArrayList<Category>();
		categoryList.add(category);
		Film film = new Film(1,"sholey","abcd",new Date(),(byte)5,new Date(),new Date(),(short)34,null,null,null);
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(film);

		Mockito.when(filmDao.updateFilm(film)).thenReturn("Film updation failed");

		assertEquals("Film updation failed", filmService.modifyFilm(film));
	}

	@Test
	public void validInputShouldModifyFilm() {
		Category category = filmService.createCategory(1, "Action", null, null);
		List<Category> categoryList = new ArrayList<Category>();
		categoryList.add(category);
		Film film = new Film(1,"sholey","abcd",new Date(),(byte)5,new Date(),new Date(),(short)34,null,null,null);
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(film);
		Mockito.when(filmDao.updateFilm(film)).thenReturn("Film updated successfully");
		assertEquals("Film updated successfully", filmService.modifyFilm(film));
	}

	@Test
	public void validInputShouldNotModifyFilm() {
		Date date = new Date();
		Category category = filmService.createCategory(1, "Action", null, null);
		List<Category> categoryList = new ArrayList<Category>();
		categoryList.add(category);
		Film film = new Film(1,"sholey","abcd",new Date(),(byte)5,new Date(),new Date(),(short)34,null,null,null);
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(film);
		Mockito.when(filmDao.updateFilm(film)).thenReturn("Film updation failed");
		assertEquals("Film updation failed", filmService.modifyFilm(film));
	}

	// Delete Film
	// 1. If input is null, it should not search.
	// 2. If input value is not present, it should throw error.
	// 3. If input value is present, then it should return film object.
	// 4. If the value is present and the system cannot return the object, then it should show error.

	@Test(expected=NullPointerException.class)
	public void nullInputShouldNotDeleteFilm() {
		Category category = filmService.createCategory(1, "Action", null, null);
		List<Category> categoryList = new ArrayList<Category>();
		categoryList.add(category);
		Film film = new Film(1,"sholey","abcd",new Date(),(byte)5,new Date(),new Date(),(short)34,null,null,null);
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(film);
		Mockito.when(filmDao.removeFilm(null)).thenThrow(NullPointerException.class);
		filmService.deleteFilm(null);
	
	}

	@Test
	public void invalidInputShouldNotDeleteFilm() {
		Category category = filmService.createCategory(1, "Action", null, null);
		List<Category> categoryList = new ArrayList<Category>();
		categoryList.add(category);
		Film film = new Film(1,"sholey","abcd",new Date(),(byte)5,new Date(),new Date(),(short)34,null,null,null);
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(film);

		Mockito.when(filmDao.removeFilm(film)).thenReturn("Film deletion failed");

		assertEquals("Film deletion failed", filmService.deleteFilm(film));
	}

	@Test
	public void validInputShouldDeleteFilm() {
		Category category = filmService.createCategory(1, "Action", null, null);
		List<Category> categoryList = new ArrayList<Category>();
		categoryList.add(category);
		Film film = new Film(1,"sholey","abcd",new Date(),(byte)5,new Date(),new Date(),(short)34,null,null,null);
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(film);
		Mockito.when(filmDao.removeFilm(film)).thenReturn("Film deleted");
		assertEquals("Film deleted", filmService.deleteFilm(film));
	}

	@Test
	public void validInputShouldNotDeleteFilm() {
		Date date = new Date();
		Category category = filmService.createCategory(1, "Action", null, null);
		List<Category> categoryList = new ArrayList<Category>();
		categoryList.add(category);
		Film film = new Film(1,"sholey","abcd",new Date(),(byte)5,new Date(),new Date(),(short)34,null,null,null);
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(film);
		Mockito.when(filmDao.removeFilm(film)).thenReturn("Film deletion failed");
		assertEquals("Film deletion failed", filmService.deleteFilm(film));
	}

	// Add Actor
	// 1. If any parameter is invalid, value should not be added.
	// 2. If all the input parameters are valid, then the film object should be added.
	// 3. If all the parameters are valid but the film object is not added, then system should throw error.
    // 4. If the actor is null then it should throw exception
	@Test
	public void invalidParameterForActor() {
		Actor actor = new Actor();
		Mockito.when(actorDao.addActor(new Actor())).thenReturn(false);
		assertEquals("Actor not added", actorService.addActor(new Actor()));
	}

	@Test
	public void validParameterForActor() {
		Actor actor = new Actor();
		Mockito.when(actorDao.addActor(actor)).thenReturn(true);
		assertEquals("Actor added", actorService.addActor(actor));
	}

	@Test
	public void systemErrorForActor() {
		Actor actor = new Actor();
		Mockito.when(actorDao.addActor(actor)).thenReturn(false);
		assertEquals("Actor not added", actorService.addActor(actor));
	}
	
	@Test(expected=Exception.class)
	public void nullActorInputShouldThrowException() {
		Film film = new Film(1,"sholey","abcd",new Date(),(byte)5,new Date(),new Date(),(short)34,null,null,null);
		Mockito.when(actorDao.addActor(null)).thenThrow(Exception.class);
		actorService.addActor(null);
	}

	// Search By name of Actor
	// 1. If input is null, it should not search.
	// 2. If input value is not present, it should throw error.
	// 3. If input value is present, then it should return film object.
	// 4. If the value is present and the system cannot return the object, then it should show error.

	@Test
	public void nullInputShouldNotSearchByname() {
		Actor actor = new Actor();
		List<Actor> actorList = new ArrayList<Actor>();
		Mockito.when(actorDao.findActorByName(null)).thenReturn(actorList);
		assertEquals(actorList, actorService.findActorByName(null));
	}

	@Test
	public void invalidInputShouldNotSearchByname() {
		Actor actor = new Actor();
		List<Actor> actorList = new ArrayList<Actor>();
		Mockito.when(actorDao.findActorByName("Katrina")).thenReturn(actorList);
		assertEquals(actorList, actorService.findActorByName("Katrina"));
	}

	@Test
	public void validInputShouldSearchByname() {
		Actor actor = new Actor();
		List<Actor> actorList = new ArrayList<Actor>();
		Mockito.when(actorDao.findActorByName("Diya")).thenReturn(actorList);
		assertEquals(actorList, actorService.findActorByName("Diya"));
	}

	@Test
	public void validInputShouldNotSearchByname() {
		Actor actor = new Actor();
		List<Actor> actorList = new ArrayList<Actor>();
		Mockito.when(actorDao.findActorByName("Diya")).thenReturn(null);
		assertEquals(null, actorService.findActorByName("Diya"));
	}

	// Search By gender of Actor
	// 1. If input is null, it should not search.
	// 2. If input value is not present, it should throw error.
	// 3. If input value is present, then it should return film object.
	// 4. If the value is present and the system cannot return the object, then it should show error.

	@Test
	public void nullInputShouldNotSearchByGender() {
		Actor actor = new Actor();
		List<Actor> actorList = new ArrayList<Actor>();
		Mockito.when(actorDao.findActorByGender(null)).thenReturn(actorList);
		assertEquals(actorList, actorService.findActorByGender(null));
	}

	@Test
	public void invalidInputShouldNotSearchByGender() {
		Actor actor = new Actor();
		List<Actor> actorList = new ArrayList<Actor>();
		Mockito.when(actorDao.findActorByGender("Male")).thenReturn(actorList);
		assertEquals(actorList, actorService.findActorByGender("Male"));
	}

	@Test
	public void validInputShouldSearchByGender() {
		Actor actor = new Actor();
		List<Actor> actorList = new ArrayList<Actor>();
		Mockito.when(actorDao.findActorByGender("Female")).thenReturn(actorList);
		assertEquals(actorList, actorService.findActorByGender("Female"));
	}

	@Test
	public void validInputShouldNotSearchByGender() {
		Actor actor = new Actor();
		List<Actor> actorList = new ArrayList<Actor>();
		Mockito.when(actorDao.findActorByGender("Female")).thenReturn(null);
		assertEquals(null, actorService.findActorByGender("Female"));
	}
	
	// Delete Actor
	// 1. If input is null, it should not search.
	// 2. If input value is not present, it should throw error.
	// 3. If input value is present, then it should return film object.
	// 4. If the value is present and the system cannot return the object, then it should show error.

		@Test(expected=NullPointerException.class)
		public void nullInputShouldNotDeleteActor() {
			Actor actor = new Actor();
			Mockito.when(actorDao.deleteActor(null)).thenThrow(NullPointerException.class);
			actorService.removeActor(null);
		}

		@Test
		public void invalidInputShouldNotDeleteActor() {
			Actor actor = new Actor();
			Mockito.when(actorDao.deleteActor(actor)).thenReturn("Actor cannot be deleted");
			assertEquals("Actor cannot be deleted",actorService.removeActor(actor));
		}

		@Test
		public void validInputShouldDeleteActor() {
			Actor actor = new Actor();
			Mockito.when(actorDao.deleteActor(actor)).thenReturn("Actor deleted");
			assertEquals("Actor deleted", actorService.removeActor(actor));
		}

		@Test
		public void validInputShouldNotDeleteActor() {
			Actor actor = new Actor();
			Mockito.when(actorDao.deleteActor(actor)).thenReturn("Actor cannot be deleted");
			assertEquals("Actor cannot be deleted", actorService.removeActor(actor));
		}
		
		// Modify Actor
		// 1. If input is null, it should not search.
		// 2. If input value is not present, it should throw error.
		// 3. If input value is present, then it should return film object.
		// 4. If the value is present and the system cannot return the object, then it should show error.

		@Test
		public void nullInputShouldNotModifyActor() {
			Actor actor = new Actor();
			Mockito.when(actorDao.updateActor(actor)).thenReturn(null);
			assertEquals(null, actorService.modifyActor(actor));
		}

		@Test
		public void invalidInputShouldNotModifyActor() {
			Actor actor = new Actor();
			Mockito.when(actorDao.updateActor(actor)).thenReturn(null);

			assertEquals(null, actorService.modifyActor(actor));
		}

		@Test
		public void validInputShouldModifyActor() {
			Actor actor = new Actor();
			Mockito.when(actorDao.updateActor(actor)).thenReturn(actor);
			assertEquals(actor, actorService.modifyActor(actor));
		}

		@Test
		public void validInputShouldNotModifyActor() {
			Actor actor = new Actor();
			Mockito.when(actorDao.updateActor(actor)).thenReturn(null);
			assertEquals(null, actorService.modifyActor(actor));
		}



}
